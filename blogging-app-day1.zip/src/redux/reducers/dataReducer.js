
const initialState = {
    posts: [],
    singlePost: {},
};

const dataReducer = (state=initialState, action) => {
    return state;
}
export default dataReducer;