const initialState = {
    authenticated: false,
    user: {},
}

const userReducer = (state=initialState, action) => {
    return state;
}
export default userReducer;